// Admin extras: Excel reports, background photos and the activity log.
const express = require('express');
const { pool } = require('../config/db');
const { getSettings } = require('../lib/settings');
const { wrap, cleanText } = require('../lib/helpers');
const { audit } = require('../lib/audit');
const { SLOTS, mediaVersions } = require('../lib/media');
const { buildWorkbook } = require('../lib/report');
const { snapshot } = require('../lib/finance');
const { getFigures, saveFigures } = require('../lib/figures');
const { reportsPage } = require('../views/admin/reports');
const { takingsPage } = require('../views/admin/takings');
const { getTakings } = require('../lib/takings');
const { sendWorkbook } = require('../lib/xlsx-export');
const { photosPage } = require('../views/admin/photos');
const { activityPage } = require('../views/admin/activity');

const MAX_PHOTO = 2.5 * 1024 * 1024;
const YMD = /^\d{4}-\d{2}-\d{2}$/;
const validYmd = (s) => YMD.test(s || '') && !Number.isNaN(Date.parse(`${s}T00:00:00Z`)) && new Date(`${s}T00:00:00Z`).toISOString().slice(0, 10) === s;

// Index-friendly range on created_at, using Nairobi calendar days.
const RANGE = `r.created_at >= ($1::date)::timestamp AT TIME ZONE 'Africa/Nairobi' AND r.created_at < (($2::date + 1)::timestamp AT TIME ZONE 'Africa/Nairobi')`;

const addDays = (ymd, n) => {
  const d = new Date(`${ymd}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};

async function todayNairobi() {
  const { rows } = await pool.query(`SELECT to_char(now() AT TIME ZONE 'Africa/Nairobi', 'YYYY-MM-DD') AS d`);
  return rows[0].d;
}

function presets(today) {
  const y = today.slice(0, 4);
  const m = today.slice(0, 7);
  const firstThis = `${m}-01`;
  const lastPrev = addDays(firstThis, -1);
  return [
    ['This month', firstThis, today],
    ['Last month', `${lastPrev.slice(0, 7)}-01`, lastPrev],
    ['Last 30 days', addDays(today, -29), today],
    ['Last 90 days', addDays(today, -89), today],
    ['This year', `${y}-01-01`, today],
    ['All time', '2000-01-01', today],
  ];
}

async function resolveRange(q) {
  const today = await todayNairobi();
  let from = cleanText(q.from, 10);
  let to = cleanText(q.to, 10);
  if (!validYmd(from)) from = `${today.slice(0, 7)}-01`;
  if (!validYmd(to)) to = today;
  if (from > to) [from, to] = [to, from];
  return { from, to, today };
}

module.exports = function mount(router, { buildCtx, flash, need }) {
  /* ---------- daily takings ---------- */
  router.get(
    '/takings',
    need('reports'),
    wrap(async (req, res) => {
      const { from, to, today } = await resolveRange(req.query);
      const [ctx, data, snap] = await Promise.all([buildCtx(req), getTakings(from, to), snapshot(from, to)]);
      res.view(takingsPage(ctx, { from, to, presets: presets(today), snap, data }));
    })
  );

  router.get(
    '/takings/download',
    need('reports'),
    wrap(async (req, res) => {
      const { from, to } = await resolveRange(req.query);
      const [settings, data] = await Promise.all([getSettings(), getTakings(from, to)]);
      const cur = settings.currency;
      const sub = `${settings.business_name || 'Tap to Wash'} - ${from} to ${to} - amounts in ${cur}`;
      const days = [...data.days].sort((a, b) => (a.day < b.day ? -1 : 1));
      await audit(req, 'takings_download', `Daily takings ${from} to ${to}`);
      await sendWorkbook(res, `Daily takings ${from} to ${to}.xlsx`, {
        title: 'Daily takings',
        sheets: [
          {
            name: 'Daily takings', title: 'Daily takings by payment method', subtitle: sub, landscape: false,
            columns: [
              { header: 'Date', width: 16, type: 'date' },
              { header: 'M-Pesa', width: 16, type: 'money' },
              { header: 'Cash', width: 16, type: 'money' },
              { header: 'Total received', width: 18, type: 'money', formula: (r) => `=B${r}+C${r}`, result: (v) => Number(v[1]) + Number(v[2]) },
              { header: 'Unpaid (orders made that day)', width: 22, type: 'money', wrap: true },
            ],
            rows: days.map((d) => [d.day, d.mpesa, d.cash, 0, d.unpaid]),
            totals: [{ col: 1, kind: 'sum' }, { col: 2, kind: 'sum' }, { col: 3, kind: 'sum' }, { col: 4, kind: 'sum' }],
          },
          {
            name: 'Payments', title: 'Payments received', subtitle: sub, landscape: true,
            columns: [
              { header: 'Time', width: 18, type: 'text' }, { header: 'Order', width: 16, type: 'text' }, { header: 'Customer', width: 24, type: 'text' },
              { header: 'Method', width: 12, type: 'text' }, { header: 'M-Pesa code', width: 16, type: 'text' }, { header: 'Recorded by', width: 20, type: 'text' },
              { header: 'Amount', width: 14, type: 'money' },
            ],
            rows: data.payments.map((p) => [p.at, p.ref_code, p.customer, p.method === 'mpesa' ? 'M-Pesa' : 'Cash', p.method === 'mpesa' ? p.reference : '', p.recorded_by, p.amount]),
            totals: [{ col: 6, kind: 'sum' }],
          },
          {
            name: 'Unpaid orders', title: 'Unpaid orders', subtitle: sub, landscape: true,
            columns: [
              { header: 'Order date', width: 14, type: 'date' }, { header: 'Order', width: 16, type: 'text' }, { header: 'Customer', width: 24, type: 'text' },
              { header: 'Phone', width: 16, type: 'text' }, { header: 'Billed', width: 14, type: 'money' }, { header: 'Paid', width: 14, type: 'money' },
              { header: 'Balance', width: 14, type: 'money', formula: (r) => `=MAX(E${r}-F${r},0)`, result: (v) => Math.max(0, Number(v[4]) - Number(v[5])) },
            ],
            rows: data.unpaidOrders.map((o) => [o.day, o.ref_code, o.customer, o.phone, o.total_amount, o.amount_paid, 0]),
            totals: [{ col: 4, kind: 'sum' }, { col: 5, kind: 'sum' }, { col: 6, kind: 'sum' }],
          },
        ],
      });
    })
  );

  /* ---------- reports ---------- */
  router.get(
    '/reports',
    need('reports'),
    wrap(async (req, res) => {
      const { from, to, today } = await resolveRange(req.query);
      const DR = RANGE.replace(/\br\./g, 'd.');
      const [ctx, k, del, figures, snap] = await Promise.all([
        buildCtx(req),
        pool.query(
          `SELECT COUNT(*)::int AS requests,
                  COUNT(*) FILTER (WHERE r.status = 'delivered')::int AS delivered,
                  COALESCE(SUM(r.total_amount), 0) AS billed,
                  COALESCE(SUM(r.amount_paid), 0) AS collected,
                  COALESCE(SUM(GREATEST(r.total_amount - r.amount_paid, 0)) FILTER (WHERE r.status <> 'cancelled'), 0) AS outstanding
             FROM requests r WHERE ${RANGE}`,
          [from, to]
        ),
        // Deleted requests: their money still counts as billed and collected.
        pool.query(`SELECT COALESCE(SUM(d.total_amount), 0) AS billed, COALESCE(SUM(d.amount_paid), 0) AS collected FROM deleted_requests d WHERE ${DR}`, [from, to]),
        getFigures(),
        snapshot(from, to),
      ]);
      const kpi = { ...k.rows[0], billed: Number(k.rows[0].billed) + Number(del.rows[0].billed), collected: Number(k.rows[0].collected) + Number(del.rows[0].collected) };
      res.view(reportsPage(ctx, { from, to, kpi, presets: presets(today), figures, snap }));
    })
  );

  // Business figures used by the report's Inputs sheet (owner and manager, same permission as Reports).
  router.post(
    '/reports/figures',
    need('reports'),
    wrap(async (req, res) => {
      const r = await saveFigures(req.body, req.session.admin.id);
      if (r.problems.length) {
        flash(req, 'error', `Nothing was saved. ${r.problems.slice(0, 3).join(' ')}${r.problems.length > 3 ? ` (and ${r.problems.length - 3} more)` : ''}`);
      } else {
        await audit(req, 'report_figures_saved', `${r.saved} business figures saved`);
        flash(req, 'success', 'Business figures saved. The next Excel report will use them.');
      }
      res.redirect('/admin/reports#figures');
    })
  );

  router.get(
    '/reports/download',
    need('reports'),
    wrap(async (req, res) => {
      const { from, to } = await resolveRange(req.query);
      const DR = RANGE.replace(/\br\./g, 'd.');
      const [settings, reqs, itemRows, custs, cats, delRows, figures] = await Promise.all([
        getSettings(),
        pool.query(
          `SELECT r.ref_code, to_char((r.created_at AT TIME ZONE 'Africa/Nairobi')::date, 'YYYY-MM-DD') AS day, r.status, r.location_description,
                  r.total_amount, r.amount_paid, r.terms_version, c.name AS customer_name, c.phone AS customer_phone,
                  (SELECT string_agg((i.category_name || COALESCE(' – ' || i.option_name, '')) || ' x' || i.quantity, ', ' ORDER BY i.id) FROM request_items i WHERE i.request_id = r.id) AS items,
                  (SELECT to_char((max(e.created_at) AT TIME ZONE 'Africa/Nairobi')::date, 'YYYY-MM-DD') FROM request_events e WHERE e.request_id = r.id AND e.status = 'delivered') AS delivered_day
             FROM requests r JOIN customers c ON c.id = r.customer_id
            WHERE ${RANGE} ORDER BY r.created_at DESC LIMIT 5001`,
          [from, to]
        ),
        pool.query(
          `SELECT r.ref_code, to_char((r.created_at AT TIME ZONE 'Africa/Nairobi')::date, 'YYYY-MM-DD') AS day, i.category_name, i.quantity
             FROM request_items i JOIN requests r ON r.id = i.request_id
            WHERE ${RANGE} AND r.status <> 'cancelled' ORDER BY r.created_at DESC, i.id LIMIT 10001`,
          [from, to]
        ),
        pool.query(
          `SELECT c.name, c.phone, MAX(r.created_at) AS last
             FROM customers c JOIN requests r ON r.customer_id = c.id
            WHERE ${RANGE} GROUP BY c.id ORDER BY MAX(r.created_at) DESC LIMIT 2001`,
          [from, to]
        ),
        pool.query('SELECT name, unit, price, is_active FROM categories ORDER BY sort_order, name LIMIT 100'),
        pool.query(
          `SELECT d.ref_code, to_char((d.created_at AT TIME ZONE 'Africa/Nairobi')::date, 'YYYY-MM-DD') AS day, 'deleted' AS status, '' AS location_description,
                  d.total_amount, d.amount_paid, NULL AS terms_version, d.customer_name, d.customer_phone, '(request deleted - money kept)' AS items, NULL AS delivered_day
             FROM deleted_requests d WHERE ${DR} AND d.amount_paid > 0 ORDER BY d.created_at DESC LIMIT 1000`,
          [from, to]
        ),
        getFigures(),
      ]);
      reqs.rows.push(...delRows.rows); // money earned on deleted requests stays in the report
      const truncated = { requests: reqs.rows.length > 5000, items: itemRows.rows.length > 10000, customers: custs.rows.length > 2000 };
      const wb = await buildWorkbook({
        settings,
        from,
        to,
        requests: reqs.rows.slice(0, 5000),
        items: itemRows.rows.slice(0, 10000),
        customers: custs.rows.slice(0, 2000),
        categories: cats.rows,
        truncated,
        figures,
      });
      const buf = await wb.xlsx.writeBuffer();
      await audit(req, 'report_download', `Excel report ${from} to ${to}`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="TapToWash_Report_${from}_to_${to}.xlsx"`);
      res.send(Buffer.from(buf));
    })
  );

  /* ---------- background photos ---------- */
  router.get(
    '/photos',
    need('photos'),
    wrap(async (req, res) => {
      const [ctx, versions] = await Promise.all([buildCtx(req), mediaVersions()]);
      res.view(photosPage(ctx, { versions }));
    })
  );

  router.post(
    '/photos/:slot',
    need('photos'),
    express.raw({ type: 'image/jpeg', limit: '3mb' }),
    wrap(async (req, res) => {
      const slot = req.params.slot;
      const buf = req.body;
      if (!Object.prototype.hasOwnProperty.call(SLOTS, slot)) return res.status(404).json({ ok: false, error: 'Unknown picture slot.' });
      if (!Buffer.isBuffer(buf) || buf.length < 1000) return res.status(400).json({ ok: false, error: 'No image received.' });
      if (buf.length > MAX_PHOTO) return res.status(413).json({ ok: false, error: 'That image is too large. Choose a smaller one.' });
      // Only real JPEG files: starts with FF D8 FF and ends with FF D9.
      if (!(buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) || !(buf[buf.length - 2] === 0xff && buf[buf.length - 1] === 0xd9)) {
        return res.status(400).json({ ok: false, error: 'Only JPEG pictures are accepted.' });
      }
      await pool.query(
        `INSERT INTO media (slot, mime, data, updated_at) VALUES ($1, 'image/jpeg', $2, now())
         ON CONFLICT (slot) DO UPDATE SET mime = EXCLUDED.mime, data = EXCLUDED.data, updated_at = now()`,
        [slot, buf]
      );
      await audit(req, 'photo_upload', `${slot} (${Math.round(buf.length / 1024)} KB)`);
      res.json({ ok: true });
    })
  );

  router.post(
    '/photos/:slot/reset',
    need('photos'),
    wrap(async (req, res) => {
      if (Object.prototype.hasOwnProperty.call(SLOTS, req.params.slot)) {
        await pool.query('DELETE FROM media WHERE slot = $1', [req.params.slot]);
        await audit(req, 'photo_reset', req.params.slot);
        flash(req, 'success', 'Picture reset to the default illustration.');
      }
      res.redirect('/admin/photos');
    })
  );

  /* ---------- site icon (favicon), kept in the database ---------- */
  const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const PNG_END = Buffer.from([0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82]);

  router.post(
    '/settings/favicon',
    need('settings'),
    express.raw({ type: 'image/png', limit: '1mb' }),
    wrap(async (req, res) => {
      const buf = req.body;
      if (!Buffer.isBuffer(buf) || buf.length < 100) return res.status(400).json({ ok: false, error: 'No image received.' });
      // Only a real PNG file: correct signature and ending, and a square picture (the browser prepares a 512 x 512 one).
      if (!buf.subarray(0, 8).equals(PNG_SIG) || !buf.subarray(buf.length - 12).equals(PNG_END)) {
        return res.status(400).json({ ok: false, error: 'Only PNG pictures are accepted here. Choose the file again.' });
      }
      const w = buf.readUInt32BE(16);
      const h = buf.readUInt32BE(20);
      if (w !== h || w < 32 || w > 1024) return res.status(400).json({ ok: false, error: 'The icon must be a square picture.' });
      await pool.query(
        `INSERT INTO media (slot, mime, data, updated_at) VALUES ('favicon', 'image/png', $1, now())
         ON CONFLICT (slot) DO UPDATE SET mime = EXCLUDED.mime, data = EXCLUDED.data, updated_at = now()`,
        [buf]
      );
      await audit(req, 'favicon_upload', `${w}x${h} (${Math.round(buf.length / 1024)} KB)`);
      res.json({ ok: true });
    })
  );

  router.post(
    '/settings/favicon/reset',
    need('settings'),
    wrap(async (req, res) => {
      await pool.query(`DELETE FROM media WHERE slot = 'favicon'`);
      await audit(req, 'favicon_reset', 'Back to the built-in icon');
      flash(req, 'success', 'Site icon reset to the built-in icon.');
      res.redirect('/admin/settings');
    })
  );

  /* ---------- activity log ---------- */
  router.get(
    '/activity',
    need('activity'),
    wrap(async (req, res) => {
      const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
      const size = 30;
      const [ctx, count, rows] = await Promise.all([
        buildCtx(req),
        pool.query('SELECT COUNT(*)::int AS n FROM audit_log'),
        pool.query('SELECT admin_email, action, detail, ip, created_at FROM audit_log ORDER BY created_at DESC, id DESC LIMIT $1 OFFSET $2', [size, (page - 1) * size]),
      ]);
      const total = count.rows[0].n;
      res.view(activityPage(ctx, { rows: rows.rows, total, page, pages: Math.max(Math.ceil(total / size), 1) }));
    })
  );
};
